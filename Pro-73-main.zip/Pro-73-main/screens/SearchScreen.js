import React from 'react';
import {Text, View} from 'react-native';

export default class SearchScreen extends React.Component{
    render(){
        return(
            <View>

            <Text>search</Text>

            </View>
        )
    }
}